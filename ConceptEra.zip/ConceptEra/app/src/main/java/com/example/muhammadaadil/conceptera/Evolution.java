package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Evolution extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evolution);

        Button int_btn = (Button) findViewById(R.id.Intro_to_evolution);
        int_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Evolution.this , intro_to_evolution.class);
                startActivity(i);
            }
        });

        Button dwn_btn = (Button) findViewById(R.id.Evolution_Darwin);
        dwn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Evolution.this , Evolution_Darwin.class);
                startActivity(i);
            }
        });

        Button lam_btn = (Button) findViewById(R.id.Evolution_Lamarck);
        lam_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Evolution.this , Evolution_Lamarck.class);
                startActivity(i);
            }
        });

        Button mac_btn = (Button) findViewById(R.id.Macroevolution);
        mac_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Evolution.this , MacroEvolution.class);
                startActivity(i);
            }
        });




    }
}
