package com.example.muhammadaadil.conceptera;

public class Questionairre {


    public String questions[] = {
            "Formula of 'ytterbium dibromide'?",
            "Formula of 'zinc bromide'?",
            "Formula of 'lead carbonate'?",
            "Formula of 'polonium trioxide'?",
            "Formula of 'rubidium chlorite'?"

    };

    public String choices[][] = {
            {"YbBr2", "YbBr", "YbBr3", "YbCl"},
            {"ZnBr", "ZnBr2", "ZnBr4", "ZnB"},
            {"Pb3CO2", "PbCO", "PbCO3", "PbCO2"},
            {"PoO", "PoO2", "PO3", "PoO3"},
            {"RbClO3", "RbCl", "RbClO2", "RbClO"},
            {"PoO", "PoO2", "PO3", "PoO3"}
    };

    public String correctAnswer[] = {
            "YbBr2",
            "ZnBr2",
            "PbCO3",
            "PoO3",
            "RbClO2"
    };

    public String getQuestion(int a){
        String question = questions[a];
        return question;
    }

    public String getchoice1(int a){
        String choice = choices[a][0];
        return choice;
    }

    public String getchoice2(int a){
        String choice = choices[a][1];
        return choice;
    }

    public String getchoice3(int a){
        String choice = choices[a][2];
        return choice;
    }

    public String getchoice4(int a){
        String choice = choices[a][3];
        return choice;
    }

    public String getCorrectAnswer(int a){
        String answer = correctAnswer[a];
        return answer;
    }
}
