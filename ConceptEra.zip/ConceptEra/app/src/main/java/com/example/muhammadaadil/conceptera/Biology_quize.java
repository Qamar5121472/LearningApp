package com.example.muhammadaadil.conceptera;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Biology_quize extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biology_quize);
    }
}
