package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class cell_division extends AppCompatActivity {

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cell_division);
        Button prokaryotic_btn = (Button) findViewById(R.id.prokaryotic_division);
        prokaryotic_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(cell_division.this , Prokaryotic_division.class);
                startActivity(i);

            }
        });
        Button eukaryotic_btn = (Button) findViewById(R.id.eukaryotic_division);
        eukaryotic_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(cell_division.this , Eukaryotic_Division.class);
                startActivity(i);
            }
        });
        Button mitosis_btn = (Button) findViewById(R.id.mitosis);
        mitosis_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(cell_division.this , Mitosis.class);
                startActivity(i);
            }
        });
        Button meiosis_btn = (Button) findViewById(R.id.meiosis);
        meiosis_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(cell_division.this , Meiosis.class);
                startActivity(i);
            }
        });


    }
}
