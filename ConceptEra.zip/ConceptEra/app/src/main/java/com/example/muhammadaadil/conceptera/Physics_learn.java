package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Physics_learn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_physics_learn);

        Button defi_btn = (Button)findViewById(R.id.defination_of_physics);
        defi_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Physics_learn.this, Defination_of_physics.class);
                startActivity(i);
            }
        });

        Button branches_btn = (Button)findViewById(R.id.Branches_of_physics);
        branches_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Physics_learn.this, Branches_of_physics.class);
                startActivity(i);



            }
        });
        Button laws_btn =(Button)findViewById(R.id.Laws);
        laws_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent( Physics_learn.this,Laws.class);
                startActivity(j);
            }
        });


    }
}
