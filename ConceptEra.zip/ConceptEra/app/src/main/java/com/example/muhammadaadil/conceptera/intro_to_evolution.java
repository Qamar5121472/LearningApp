package com.example.muhammadaadil.conceptera;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class intro_to_evolution extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro_to_evolution);
    }
}
