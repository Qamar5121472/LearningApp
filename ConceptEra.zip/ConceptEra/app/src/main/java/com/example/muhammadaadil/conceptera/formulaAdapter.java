package com.example.muhammadaadil.conceptera;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class formulaAdapter extends ArrayAdapter<Elements> {
        private int mColorResourceId;
    public formulaAdapter(@NonNull Context context, ArrayList<Elements> elements) {
        super(context,0, elements);
        //mColorResourceId = ColorResourceId;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View listItemView = convertView;
        if (listItemView == null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.formula_list_item, parent, false);
        }

        Elements currentElement = (Elements) getItem(position);

        TextView formula = (TextView)listItemView.findViewById(R.id.formulae);
        formula.setText(currentElement.getmFormula());

        TextView formulaName = (TextView)listItemView.findViewById(R.id.chem_name);
        formulaName.setText(currentElement.getmChemical_name());

        return listItemView;
    }
}
