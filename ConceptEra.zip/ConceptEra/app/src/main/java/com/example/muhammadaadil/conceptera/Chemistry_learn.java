package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Chemistry_learn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chemistry_learn);
        Button brn_btn = (Button) findViewById(R.id.Branches_of_chem);
        brn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =  new Intent(Chemistry_learn.this , bran_of_chem.class);
                startActivity(i);
            }
        });


        Button for_btn = (Button) findViewById(R.id.formula);
        for_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =  new Intent(Chemistry_learn.this,Formula_Listview.class);
                startActivity(i);
            }
        });

        Button cnc_btn = (Button) findViewById(R.id.concepts);
        cnc_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Chemistry_learn.this , Concepts_of_Chemistry.class);
                startActivity(i);
            }
        });
        Button cns_btn = (Button) findViewById(R.id.concepts_of_chem);
        cns_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Chemistry_learn.this , Concepts_of_Chem.class);
                startActivity(i);
            }
        });


    }
}
