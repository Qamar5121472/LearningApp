package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Physics extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_physics);

        Button lrn_btn = (Button)findViewById(R.id.physics_Learn);
        lrn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Physics.this , Physics_learn.class);
                startActivity(i);
            }
        });
        Button qui_btn = (Button) findViewById(R.id.physics_quiz);
        qui_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Physics.this , Physics_quize.class);
                startActivity(i);
            }
        });




    }
}
