package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Concepts_of_Chemistry extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_concepts_of__chemistry);

        Button cgl_btn = (Button) findViewById(R.id.Combined_Gas_Law);
        cgl_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Concepts_of_Chemistry.this , Combine_gas_law.class);
                startActivity(i);
            }
        });
        Button dlt_btn = (Button) findViewById(R.id.Dalton_law);
        dlt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Concepts_of_Chemistry.this , Dalton_law.class);
                startActivity(i);
            }
        });
        Button auf_btn = (Button) findViewById(R.id.Aufbau_Principle);
        auf_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Concepts_of_Chemistry.this , Aufbau_Principle.class);
                startActivity(i);
            }
        });

    }
}
