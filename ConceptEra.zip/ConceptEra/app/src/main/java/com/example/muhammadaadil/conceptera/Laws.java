package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Laws extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laws);

        Button mtn_btn = (Button)findViewById(R.id.laws_of_motion);
        mtn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Laws.this,Laws_of_Motion.class);
                startActivity(i);
                   }
        });
        Button lcm_btn = (Button)findViewById(R.id.Law_of_cons_momentum);
        lcm_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Laws.this, Law_of_cons_momentum.class);
                startActivity(i);
            }
        });

        Button equ_btn =(Button) findViewById(R.id.equilibrium);
        equ_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Laws.this,Equilibrium.class);
                startActivity(i);


            }
        });
        Button pas_btn = (Button) findViewById(R.id.pascal_law);
        pas_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Laws.this, pascal_law.class);
                startActivity(i);
            }
        });
        Button archi_btn = (Button) findViewById(R.id.archimedes_principle);
        archi_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Laws.this , archimedes_principle.class);
                startActivity(i);
            }
        });
        Button boyles_btn = (Button) findViewById(R.id.Boyles_law);
        boyles_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Laws.this, Boyles_law.class);
                startActivity(i);

            }
        });
        Button hooke_btn = (Button) findViewById(R.id.Hookes_Law);
        hooke_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Laws.this,Hookes_law.class);
                startActivity(i);
            }
        });
        Button young_btn = (Button) findViewById(R.id.youngs_modulus);
        young_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Laws.this,Youngs_modulus.class);
                startActivity(i);
            }
        });









    }
}
