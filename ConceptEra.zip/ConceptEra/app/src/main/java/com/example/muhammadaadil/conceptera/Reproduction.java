package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Reproduction extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reproduction);

        Button conc_btn = (Button) findViewById(R.id.concept_of_reproduction);
        conc_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Reproduction.this , Concept_of_Reproduction.class);
                startActivity(i);
            }
        });

        Button asex_btn = (Button) findViewById(R.id.Asexual_Reproduction);
        asex_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Reproduction.this, Asexual_Reproduction.class);
                startActivity(i);

            }
        });
        Button sexua_btn = (Button) findViewById(R.id.Sexual_Reproduction);
        sexua_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Reproduction.this , Sexual_Reproduction.class);
                startActivity(i);
            }
        });

    }
}
