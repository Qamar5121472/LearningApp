package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Nervous_system extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nervous_system);

        Button cns_btn =(Button) findViewById(R.id.Central_Nervous_System);
        cns_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =  new Intent(Nervous_system.this , Central_Nervous_System.class);
                startActivity(i);
            }
        });
        Button pns_btn = (Button) findViewById(R.id.Peripheral_Nervous_System);
        pns_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Nervous_system.this , Peripheral_Nervous_System.class);
                startActivity(i);
            }
        });
        Button nerve_btn = (Button) findViewById(R.id.Nerves);
        nerve_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Nervous_system.this , Nerves.class);
                startActivity(i);
            }
        });



    }
}
