package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Biology_learn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biology_learn);

        Button bran_btn = (Button) findViewById(R.id.Branches_of_Biology);
        bran_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Biology_learn.this,Branches_of_biology.class);
                startActivity(i);
            }
        });
        Button cell_btn =(Button) findViewById(R.id.Cells_and_Tissues);
        cell_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Biology_learn.this,Cells_and_Tissues.class);
                startActivity(i);
            }
        });
        Button repro_btn = (Button) findViewById(R.id.Reproduction);
        repro_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Biology_learn.this , Reproduction.class);
                startActivity(i);
            }
        });
        Button res_btn = (Button) findViewById(R.id.Respiratory_system);
        res_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Biology_learn.this , Respiratory_System.class);
                startActivity(i);
            }
        });
        Button ner_btn = (Button) findViewById(R.id.Nervous_System);
        ner_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Biology_learn.this , Nervous_system.class);
                startActivity(i);
            }
        });
        Button evo_btn =(Button) findViewById(R.id.Evolution);
        evo_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Biology_learn.this , Evolution.class);
                startActivity(i);
            }
        });



    }
}
