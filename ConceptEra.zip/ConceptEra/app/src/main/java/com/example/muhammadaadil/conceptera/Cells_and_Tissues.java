package com.example.muhammadaadil.conceptera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Cells_and_Tissues extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cells_and__tissues);


        Button cellintro_btn = (Button) findViewById(R.id.Intro_to_cell);
        cellintro_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Cells_and_Tissues.this, intro_to_cell.class);
                startActivity(i);

            }
        });
        Button plantcell_btn = (Button) findViewById(R.id.Plant_cell);
        plantcell_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Cells_and_Tissues.this, Plant_cell.class);
                startActivity(i);

            }
        });
        Button animalcell_btn = (Button) findViewById(R.id.Animal_Cell);
        animalcell_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Cells_and_Tissues.this, Animal_cell.class);
                startActivity(i);
            }
        });
        Button introtissue_btn = (Button) findViewById(R.id.Tissue);
        introtissue_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Cells_and_Tissues.this, Tissue.class);
                startActivity(i);
            }
        });
        Button animal_btn = (Button) findViewById(R.id.Animal_Tissue);
        animal_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Cells_and_Tissues.this , Animal_Tissue.class);
                startActivity(i);
            }
        });
        Button plant_btn = (Button) findViewById(R.id.Plant_Tissue);
        plant_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Cells_and_Tissues.this , Plant_Tissue.class);
                startActivity(i);
            }
        });
        Button celldiv_btn = (Button) findViewById(R.id.Cell_division);
        celldiv_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Cells_and_Tissues.this , cell_division.class);
                startActivity(i);
            }
        });



    }
}
