package com.example.muhammadaadil.conceptera;

public class Elements {

    private String mFormula;
    private String mChemical_name;

    public Elements (String formula, String chemical_name){

        mFormula = formula;
        mChemical_name = chemical_name;
    }

    public String getmFormula(){
        return mFormula;
    }
    public String getmChemical_name(){
        return mChemical_name;
    }
}
